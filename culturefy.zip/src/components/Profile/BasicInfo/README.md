BasicInfo can have user Image prop
BasicInfo should have User Name prop
BasicInfo have User Designation prop
BasicInfo have Open To props for Open to work
Props {
    userImg: any(Image) '',
    userName?: string,
    designation?: string,
    OpenTo: string,
}