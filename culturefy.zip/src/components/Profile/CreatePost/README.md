CreatePost can have variant props for background Color
Props {
    variant?: 'primary' | 'secondary'  '',
}