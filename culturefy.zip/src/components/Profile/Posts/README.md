Posts can have postOwnerImg props for Post Owner Image
Posts can have postOwner props for Post Owner Name
Posts can have postTime props Posting Time
Posts can have postText props for Post Text
Posts can have postImg props for Post Image
Posts can have lessonNumber props for Owner Lesson Number
Posts can have lessonName props for Owner Lesson Name
Posts can have partNumber props for Owner Lesson part
Posts can have lessonNextBtn props to navigate to Owner Lesson next part
Posts can have lessonNextBtnIcon props for Owner Lesson next button icon
Posts can have reactedUserImg props for Reacted User Images
Posts can have commentsCount props for Post Comments Count
Posts can have shareCount props for Post Share Count
Posts can have currentUserImg props for Post UserImg whose seeing Image

Props {
    postOwnerImg?: any (Image), ,
    postOwner?: string, 'Post Owner Name' ,
    postTime?: string, ,
    postText: string, ,
    postImg: any (Image), ,
    lessonNumber: number, ,
    lessonName: string, ,
    partNumber: number, ,
    lessonNextBtn: string, ,
    lessonNextBtnIcon: any (Icon), ,
    reactedUserImg: string, ,
    commentsCount?: number, ,
    shareCount?: number, ,
    currentUserImg?:  any (Image), ,
}