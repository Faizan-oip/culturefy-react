ProfileCount can have variant props for followers, Likes Count
ProfileCount can have count props for followers, Likes Count
ProfileCount can have text props for specifing name like followers, Likes Count

Props {
    variant?: string ,'filled' | 'outline' | 'transparent' | 'followBtn' '',
    count?: string, ,
    text?: string, ,
}