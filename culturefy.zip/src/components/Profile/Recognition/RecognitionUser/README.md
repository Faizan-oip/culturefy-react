CreatePost can have userImg props for background Color
CreatePost can have username props for background Color
CreatePost can have time props for background Color

Props {
    userImg?: any(Image),
    username?: string,
    time?: string,
}