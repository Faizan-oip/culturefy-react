ProfileCount can have userCoverImg props for User Cover Image
Props {
    userCoverImg: any (image),
}