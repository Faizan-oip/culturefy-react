
Event should ownerImg of Event
Event should have Event Title
Event should have Event Details
Event should have Event Seen by Users
Event should have Images of Event Seened Users
Props {
    ownerImg: any(Image)?,
    seenedUser: any(Image)?,
    eventTitle: string?,
    eventDetails: string?,
    eventSeen: number?,
}
