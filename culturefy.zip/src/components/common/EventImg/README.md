Event should have Event Image
Props {
    eventImage: any(Image)?,
}
