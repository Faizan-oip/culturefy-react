Recent Friend  should user image
Recent Friend  should user name

Props {
    userImg?: any(Image),
    userName?: string,
}