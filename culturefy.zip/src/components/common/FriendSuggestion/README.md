Friend Suggestion  should user image
Friend Suggestion  should user name

Friend Suggestion  can have Friend Cources Count
Friend Suggestion  can have Friend Videos Count

Props {
    userImg: any(Image)?,
    userName: string?,
    courcesCount Title: number,
    videosCount: number,
}