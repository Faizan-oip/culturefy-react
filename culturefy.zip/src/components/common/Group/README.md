Group should have image prop for Image
Group should have heading prop for heading
Group can have subHeading prop for subHeading
Group can have fontVariant prop for Group Font Variations
Group can have border prop for borders on group
Group can have action prop for actions
Props {
    image: any(Image)?,
    heading: string?,
    subHeading: string?,
    fontVariant: string, 'small' | 'large' ,
    border: string, 'borderBottom' | 'borderTop'
    subHeading: string?,
    action: any?,
}