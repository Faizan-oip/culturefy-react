Input should have variat white and offWhite BACKGROUND color
Input can have disable props
Input can have type props
Input can have color props 
Input can have placeholder props 

Props {
    variant?: 'white' | 'offWhite' ,
    disable?: Bool,
    type: string, '' 'text' | 'email' | 'date' | 'number' | 'password' ,
    color: string , ,'gray' , 'black' ,
    placeholder?:  string ,
}