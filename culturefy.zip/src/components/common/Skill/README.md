Paragraph should have label props
Paragraph should have icon props

Props {
    icon?: any , 'white' | 'offWhite' ,
    label?:  string ,
}