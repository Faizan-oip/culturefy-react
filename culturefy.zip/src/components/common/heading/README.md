Heading can have color support with theme primary and seconday color
Heading can have size variant
Heading can have border props 
Heading  should have label props

Props {
    color: string, 'primaryText' | 'secondaryText'  ,
    variant: string, 'heading3' | 'heading4' | 'heading5'  ,
    border: string, 'bottom' | 'top'  ,
    label?: string,
}