button should have variat support with theme primary and seconday color
button should have loading state support
button have disable props
button have size props
button have color props 

Props {
    variant?: 'primary' | 'secondary' ,
    isLoading?: Bool,
    disable?: Bool,
    size?: string,
    icon?: <Icon />,
    color: string , 'black' ,
}