Paragraph can have variant primary and secondary color
Paragraph should label have disable props
Props {
    variant?: string , 'white' | 'offWhite' ,
    label?:  string ,
}