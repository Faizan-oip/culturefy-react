Community1 does not have any props
It returns Newsfeed or Prfoile of Instructor | User