import React from 'react';
import {Container, Row, Col} from 'react-bootstrap'

const BlankPage = () => {
    return (
        <>
           <Container>
                <Row>
                    <Col lg="12">
                        Add Your HTML Content Here.....
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default BlankPage