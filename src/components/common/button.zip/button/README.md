
button should ke variat support with theme primary and seconday color
button should be loading state support
button have disable props

Props {
    variant?: 'filled' | 'outline' | '',
    isLoading?: Bool,
    disable?: Bool,
    icon?: <Icon />,
    label: string,
}
